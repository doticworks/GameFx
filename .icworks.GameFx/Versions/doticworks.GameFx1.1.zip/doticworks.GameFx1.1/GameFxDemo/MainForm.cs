﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/4
 * 时间: 11:52
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using doticworks.GameFx;
namespace GameFxDemo
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
			
		}
		doticworks.GameFx.IOManager giom;
		Assetor ast=new Assetor();
		Texture2T t;
		Texture2D d;
		public int num = 0;
		int numm=0;
		Bitmap bmp;
		void MainFormShown(object sender, EventArgs e)
		{
			giom=new IOManager(this);
			bmp=ast.Get_bitmap("GameFxDemo.a.gif");
			t=ast.Get_Texture2T("GameFxDemo.a.gif");
			d=new Texture2D(ast.Get_bitmap("GameFxDemo.a.gif"));
			giom.Input.KeyPress(Keys.Space, ()=> {
				num += 1;if(numm<num){numm=num;} giom.Input.TimerDelay(1000,()=>{num -= 1;});
				if(t.SetFrame(num)){t.EndAnimat();}else{t.StartAnimat();}
			});
		// 	t.StartAnimat();
			giom.Draw((g)=>{
			g.Texture(d,0,0,num*30+1,num*30+1); 
			g.Texture(t,30,30);
			g.Text("score"+num,30F,Color.Blue,0,5);
			g.Text("Maxsc"+numm,30F,Color.Blue,0,60);
			});
			
			giom.StartGame();
		}
	}
}
