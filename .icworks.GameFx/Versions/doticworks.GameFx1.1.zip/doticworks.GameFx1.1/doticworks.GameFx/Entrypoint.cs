﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/7
 * 时间: 11:30
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;

namespace doticworks.GameFx
{
	public class Assetor : doticworks.GameFx.GameFx.FxAssetor.Assetor{
		public Assetor(System.Reflection.Assembly asm):base(asm){}
		public Assetor():base(){}
	}
	public class IOManager:doticworks.GameFx.GameFx.FxIOManager.IOManager{
		public IOManager(System.Windows.Forms.Form form):base(form){}
	}
	public class FxGraphics:doticworks.GameFx.GameFx.FxIOManager.FxGraphics{
		public FxGraphics(System.Drawing.Graphics g):base(g){}
	}
	public class Texture2T:doticworks.GameFx.GameFx.Common.Texture2T{
		public Texture2T(System.Drawing.Bitmap b):base(b){}
	}
	public class Texture2D:doticworks.GameFx.GameFx.Common.Texture2D{
		public Texture2D(System.Drawing.Bitmap b):base(b){}
	}
}
