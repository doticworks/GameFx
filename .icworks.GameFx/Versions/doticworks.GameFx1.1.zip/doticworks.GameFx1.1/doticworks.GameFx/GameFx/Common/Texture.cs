﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 19:47
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.Common
{
	
	public abstract class Texture
	{
		public abstract Bitmap Paint();
		public virtual Bitmap Paint_for_catch(){return null;}
		public float Rotate=0;
		public Point Rotatepoint=new Point(0,0);
		
	}
}
