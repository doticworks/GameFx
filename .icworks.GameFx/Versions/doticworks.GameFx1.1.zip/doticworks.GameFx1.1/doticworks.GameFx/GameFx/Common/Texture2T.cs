﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 19:50
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
namespace doticworks.GameFx.GameFx.Common
{
	
	public class Texture2T: Texture
	{
		public Texture2T(Bitmap bitmap)
		{
			if(!ImageAnimator.CanAnimate(bitmap)){throw new Exception("The Image cannot animat!");}
			fd=new FrameDimension(bitmap.FrameDimensionsList[0]);
			framecount=bitmap.GetFrameCount(fd);
			_bmp=bitmap;
		}
		
		public FrameDimension fd;
		public Bitmap _bmp;
		public Bitmap _bmpcache;
		public int framecount=0;
		public int nowframe=0;
		public bool animating=false;
		public bool SetFrame(int frame){
			if(framecount<frame+1){return false;}
			if(animating){
				nowframe=frame;
			}else{
				nowframe=frame;
				_setframe();
			}return true;
		}
		void _setframe(){
			_bmpcache=_bmp;
			_bmp.SelectActiveFrame(fd,nowframe);
		}
		public void StartAnimat(){
			if(!animating){
				animating=true;
				ImageAnimator.Animate(_bmp,(s,e)=>{
				                      	ImageAnimator.UpdateFrames(_bmp);
				                      });
			}
			
		}
		public void EndAnimat(){
			if(animating){
				animating=false;
				ImageAnimator.StopAnimate(_bmp,(s,e)=>{
			                      	ImageAnimator.UpdateFrames(_bmp);
			                      });
			}
			
		}
		public override Bitmap Paint()
		{
			try{return _bmp;}catch{return _bmpcache;}
		}
		public override Bitmap Paint_for_catch()
		{
			return _bmpcache;
		}
	}
}
