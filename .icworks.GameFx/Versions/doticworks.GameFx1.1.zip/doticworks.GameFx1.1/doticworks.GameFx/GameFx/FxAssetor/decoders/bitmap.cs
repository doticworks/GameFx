﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/14
 * 时间: 19:23
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Reflection;
using System.IO;
using System.Drawing;
namespace doticworks.GameFx.GameFx.FxAssetor
{
	public partial class Assetor
	{
		public Bitmap Get_bitmap(string path){
			return new Bitmap(new MemoryStream( Get_byte(path)));
		}
		public doticworks.GameFx.Texture2T Get_Texture2T(string path){
			return new doticworks.GameFx.Texture2T(new Bitmap(new MemoryStream( Get_byte(path))));
		}
	}
}
