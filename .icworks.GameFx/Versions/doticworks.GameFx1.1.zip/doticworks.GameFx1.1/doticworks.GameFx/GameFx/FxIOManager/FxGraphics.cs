﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 20:57
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class FxGraphics
	{
		public FxGraphics(Graphics _g)
		{g=_g;}
		public Graphics g;
		public void Text(string text,float size,Color color,int x,int y){
			Font ft=new System.Drawing.Font("微软雅黑", size, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			g.DrawString(text,ft,new SolidBrush(color),x,y);
		}
		
	}
}
