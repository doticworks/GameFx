﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/14
 * 时间: 19:34
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class FxGraphics
	{
		public void Bitmap(Bitmap bmp,int x,int y){
			g.DrawImage(bmp,x,y);
		}
		public void Bitmap(Bitmap bmp,int x,int y,int w,int h){
			g.DrawImage(bmp,x,y,w,h);
		}
		public void Texture(doticworks.GameFx.GameFx.Common.Texture bmp,int x,int y){
			try{g.DrawImage(bmp.Paint(),x,y);}catch{}//g.DrawImage(bmp.Paint_for_catch(),x,y);}
		}
		public void Texture(doticworks.GameFx.GameFx.Common.Texture bmp,int x,int y,int w,int h){
			try{g.DrawImage(bmp.Paint(),x,y,w,h);}catch{}//{g.DrawImage(bmp.Paint_for_catch(),x,y);}
		}
	}
}
