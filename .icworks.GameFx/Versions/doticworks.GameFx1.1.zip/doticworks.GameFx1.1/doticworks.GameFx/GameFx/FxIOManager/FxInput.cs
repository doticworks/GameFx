﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 20:02
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class FxInput
	{
		public FxInput(Queue<Keys> inputs,
		             Dictionary<Keys,Action> keyevent_press_change,
		             Dictionary<Keys,Action> keyevent_hold_change,
		             List<Keys> _keyup_,
					List<Keys> _keydown_,
		             Control gamewindow
		            ){
			_inputs=inputs;_keyevent_press_change=keyevent_press_change;_keyevent_hold_change=keyevent_hold_change;_keyup=_keyup_;_keydown=_keydown_;
			gamewindow.KeyDown+=(s,e)=>{
				inputs.Enqueue(e.KeyData);
				if(!_keydown.Contains(e.KeyData)){
					_keydown.Add(e.KeyData);
				}
				Allkeyevent(e.KeyCode);
		//		MessageBox.Show("ha");
			};
			gamewindow.KeyUp+=(s,e)=>{
				if(_keyup.Contains(e.KeyData)){
					_keyup.Remove(e.KeyData);
				}
				if(_keydown.Contains(e.KeyData)){
					_keydown.Remove(e.KeyData);
				}
			};
		}
		Queue<Keys> _inputs;
		Dictionary<Keys,Action> _keyevent_press_change=new Dictionary<Keys, Action>();
		Dictionary<Keys,Action> _keyevent_hold_change=new Dictionary<Keys, Action>();
		List<Keys> _keyup=new List<Keys>();
		List<Keys> _keydown=new List<Keys>();
		Action<Keys> Allkeyevent=(a)=>{};
		
		public void KeyPress(Keys key,Action arg){
			if(_keyevent_press_change.ContainsKey(key)){
				_keyevent_press_change.Remove(key);
			   	_keyevent_press_change.Add(key,arg);
			}else{
				_keyevent_press_change.Add(key,arg);
			}
			
		}
		public void KeyPress(Action<Keys> arg){
			Allkeyevent=arg;
		}
		public void KeyHold(Keys key,Action arg){
			if(_keyevent_hold_change.ContainsKey(key)){
				_keyevent_hold_change.Remove(key);
			   	_keyevent_hold_change.Add(key,arg);
			}else{
				_keyevent_hold_change.Add(key,arg);
			}
			
		}
	//	public void KeyHold(Action<Keys> arg){
	//		Allkeyevent=arg;
	//	}
	}
}
