﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/4
 * 时间: 12:04
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Drawing;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	/// <summary>
	/// Description of Settings.
	/// </summary>
	public class IOMSettings
	{
		public  Color BackgroundColor=Color.White;
		public int maxfps=10;
		/// <summary>
		/// 1 To 3  big-good
		/// </summary>
		public int RenderQuality=0;
	}
}
