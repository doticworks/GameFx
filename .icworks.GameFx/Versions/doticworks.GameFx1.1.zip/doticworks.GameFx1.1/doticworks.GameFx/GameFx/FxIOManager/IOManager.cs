﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 19:51
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class IOManager
	{
		public IOManager(Form gameWindow)
		{
			_gamewindow=gameWindow;
		
			_renderTh=new Thread(()=>{Th_render();});
			_workTh=new Thread(()=>{Th_working();});
			
			
			Input=new FxInput(_inputs,_keyevent_press_change,_keyevent_hold_change,_keyup,_keydown,_gamewindow);
			
			_renderTh.IsBackground=true;
			_workTh.IsBackground=true;
		}
		void gamewindowupdated(){
			if(!locksize){
				temp=new Bitmap(picbox.Size.Width,picbox.Size.Height);
				g=Graphics.FromImage(temp);
				fg=new FxGraphics(g);
				switch(settings.RenderQuality){
						case 1:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.HighSpeed;break;
						case 2:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;break;
						case 3:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.HighQuality;break;
						default:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.Default;break;
				}
			}else{
				temp=new Bitmap(lockw,lockh);
				g=Graphics.FromImage(temp);
				fg=new FxGraphics(g);
				switch(settings.RenderQuality){
						case 1:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.HighSpeed;break;
						case 2:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;break;
						case 3:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.HighQuality;break;
						default:g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.Default;break;
				}
			}
		}
		public void UnLockSize(){
			locksize=false;
			gamewindowupdated();
		}
		public void LockSize(int w,int h){
			picbox.SizeMode=PictureBoxSizeMode.StretchImage;
			locksize=true;
			lockw=w;
			lockh=h;
			gamewindowupdated();
		}
		public void StartGame(){
			_gamewindow.Invoke(new MethodInvoker(()=>{
             	picbox=new PictureBox();
             	picbox.Parent=_gamewindow;
             	picbox.Dock=DockStyle.Fill;
             	picbox.SendToBack();
             	_gamewindow.SizeChanged+=(s,e)=>{gamewindowupdated();};
			 }));
			gamewindowupdated();
			isworking=true;
			_renderTh.Start();_workTh.Start();
		}
		public void EndGame(){
			isworking=false;
			_renderTh.Abort();_workTh.Abort();
			_gamewindow.Invoke(new MethodInvoker(()=>{
			   	picbox.Parent=null;;
			   	picbox.Dispose();
			 }));
		//	gamewindowupdated();
			
		}
	}
}
