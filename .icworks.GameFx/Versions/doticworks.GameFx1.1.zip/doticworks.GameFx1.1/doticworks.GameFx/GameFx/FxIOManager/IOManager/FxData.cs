﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 19:52
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class IOManager
	{
		Thread _renderTh;
		Thread _workTh;
		
		public doticworks.GameFx.GameFx.FxIOManager.IOMSettings settings=new IOMSettings();
		
		Form _gamewindow;
		
		PictureBox picbox;
		
		bool locksize=false;
		int lockw;
		int lockh;
		
		
		bool isworking=false;
		
		Bitmap temp=new Bitmap(1,1);
		
		public FxInput Input;
		
		Graphics g;
		FxGraphics fg;
		
		Queue<Keys> _inputs=new Queue<Keys>();
		
		#region Actions
		Action<FxGraphics> _action_draw=(g)=>{};
		List<Keys> _keyup=new List<Keys>();//diff keypress and keyhold   if up-ed it will be remove
		List<Keys> _keydown=new List<Keys>();//used to binding a key is down
		Dictionary<Keys,Action> _keyevents_press=new Dictionary<Keys, Action>();
		Dictionary<Keys,Action> _keyevent_press_change=new Dictionary<Keys, Action>();
		Dictionary<Keys,Action> _keyevents_hold=new Dictionary<Keys, Action>();
		Dictionary<Keys,Action> _keyevent_hold_change=new Dictionary<Keys, Action>();
		#endregion
	}
}
