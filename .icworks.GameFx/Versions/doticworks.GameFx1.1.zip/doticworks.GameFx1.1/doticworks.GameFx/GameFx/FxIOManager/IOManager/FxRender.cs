﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/4
 * 时间: 11:55
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class IOManager
	{
		
		public void Draw(Action<FxGraphics> arg){
			_action_draw = arg;
		}
		public void Th_render(){
			while(true){
				g.Clear(settings.BackgroundColor);
				_action_draw(fg);//InvokeCustomDrawFunc
				
				try{_gamewindow.Invoke(new MethodInvoker(()=>{
					picbox.Image=temp;
				                                     }));
				}catch{
					MessageBox.Show("cra");
				}
				Thread.Sleep(25);
			}
		}
	}
}
