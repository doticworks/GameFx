﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/7
 * 时间: 19:57
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
namespace doticworks.GameFx.GameFx.FxIOManager
{
	public partial class IOManager
	{
		public void Th_working(){
			Keys key;
			while(true){
				updatekeypresschange();updatekeyholdchange();
				if(_inputs.Count>=1){
					key=_inputs.Dequeue();
				}else{
					Thread.Sleep(5);continue;
				}
				if(!_keyup.Contains(key)){
					if(_keyevents_press.ContainsKey(key)){ _keyevents_press[key].Invoke();}
					_keyup.Add(key);
				}else{
					if(_keyevents_hold.ContainsKey(key)){ _keyevents_hold[key].Invoke();}
				}
				
			}
		}
		void updatekeypresschange(){
			foreach(var item in _keyevent_press_change){
				if(_keyevents_press.ContainsKey(item.Key)){
					_keyevents_press.Remove(item.Key);
					_keyevents_press.Add(item.Key,item.Value);
				}else{
					_keyevents_press.Add(item.Key,item.Value);
				}
			}
		}
		void updatekeyholdchange(){
			foreach(var item in _keyevent_hold_change){
				if(_keyevents_hold.ContainsKey(item.Key)){
					_keyevents_hold.Remove(item.Key);
					_keyevents_hold.Add(item.Key,item.Value);
				}else{
					_keyevents_hold.Add(item.Key,item.Value);
				}
			}
		}
	}
}
