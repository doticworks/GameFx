﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/15
 * 时间: 11:20
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Collections.Generic;
namespace doticworks.GameFx.GameFx.FxInstanceSync
{
	public class FxSyncable
	{
		public Queue<SyncCommitData> Fx_commits=new Queue<SyncCommitData>();
		public bool Fx_underSync=false;
		public bool Fx_NeedCommit=false;
		public void _Commit(){
			if(Fx_underSync){
				Fx_NeedCommit=true;
			}
		}
	}
}
