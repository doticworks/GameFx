﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/15
 * 时间: 12:03
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Reflection;
namespace doticworks.GameFx.GameFx.FxInstanceSync
{
	
	public class SyncCommitData
	{
		PropertyInfo info;
		object data;
	}
}
