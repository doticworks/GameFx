﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/11/15
 * 时间: 11:14
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Net;
using System.Threading;
namespace doticworks.GameFx.GameFx.FxInstanceSync
{
	public class InstanceSync:IDisposable
	{
		public InstanceSync(FxSyncable instance,IPEndPoint serverip)
		{
			instance.Fx_underSync=true;
			_instance=instance;
		}
		FxSyncable _instance;
		public void EndSync(){
			Dispose();
		}
		public void Dispose(){
			
		}
		void workingTh(){
			while(true){
				if(_instance.Fx_NeedCommit){
					
					
					
					
				}else{
					Thread.Sleep(20);
					continue;
				}
			}
		}
	}
}
