﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/12/19
 * 时间: 15:38
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Windows.Forms;
using SharpDX.Windows;
using SharpDX.Direct2D1;
using SharpDX.Mathematics.Interop;
using SharpDX;
using SharpDX.Direct3D;
using SharpDX.DXGI;
using D3D11=SharpDX.Direct3D11;
using System.Drawing;	
namespace doticworks.GameFx.DX
{
	/// <summary>
	/// Class with program entry point.
	/// </summary>
	internal sealed class Program
	{
		/// <summary>
		/// Program entry point.
		/// </summary>
		[STAThread]
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			var d2DFactory =new SharpDX.Direct2D1.Factory(FactoryType.MultiThreaded);
			Form fr=new Form();	
			PixelFormat pixel=new PixelFormat(Format.R8G8B8A8_UNorm,SharpDX.Direct2D1.AlphaMode.Unknown);
			HwndRenderTargetProperties hrtp=new HwndRenderTargetProperties();
			hrtp.Hwnd=fr.Handle;
			hrtp.PixelSize=new Size2(500,500);
			hrtp.PresentOptions=PresentOptions.None;
			RenderTargetProperties rtp=new RenderTargetProperties(RenderTargetType.Hardware,pixel,0,0,RenderTargetUsage.None,SharpDX.Direct2D1.FeatureLevel.Level_DEFAULT);
			RenderTarget rt=new WindowRenderTarget(d2DFactory,rtp,hrtp);
			
			SolidColorBrush scb=new SolidColorBrush(rt,ColorToRaw4(Color.FromArgb(126,128,128)));
			int col=0;
			RenderLoop.Run(fr,()=>{
			    //           	System.Threading.Thread.Sleep(5);
							col++;if(col>255){col=0;}
							rt.BeginDraw();
							rt.Clear(ColorToRaw4(Color.FromArgb(126,col,col)));
							
							rt.DrawRectangle(new RawRectangleF(col,col,col + 50,col + 50),scb, 20);
							rt.EndDraw();
			               });
			

            
			
			               	
		}
		static RawColor4 ColorToRaw4(Color color)
            {
                const float n = 255f;
                return new RawColor4(color.R / n, color.G / n, color.B / n, color.A / n);
            }
	}
}
