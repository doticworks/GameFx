﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/12/20
 * 时间: 15:05
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using SharpDX.Windows;
using SharpDX.Direct2D1;
using SharpDX.Mathematics.Interop;
using SharpDX;
using SharpDX.Direct3D;
using SharpDX.DXGI;
using D3D11=SharpDX.Direct3D11;
using System.Drawing;	
namespace doticworks.GameFx.DX
{
	/// <summary>
	/// Description of d3d_initial.
	/// </summary>
	public class d3d_initial
	{
		public d3d_initial()
		{ModeDescription backBufferDesc =new ModeDescription(500,500, new Rational(60, 1), Format.R8G8B8A8_UNorm);//w,h,fps,color DXGI_MODE_DESC
			RenderForm rf=new RenderForm("Test");
			SwapChainDescription swapChainDesc = new SwapChainDescription()
            {
                ModeDescription = backBufferDesc,
                SampleDescription = new SampleDescription(1, 0),//color quality
                Usage = Usage.RenderTargetOutput,
                BufferCount = 1,//set"1" is doubled buffer!!
                OutputHandle = rf.Handle,
                IsWindowed = true
            };
			D3D11.Device _d3DDevice;
			D3D11.DeviceContext _d3DDeviceContext;
        	SwapChain _swapChain;
        	D3D11.RenderTargetView _renderTargetView;
			D3D11.Device.CreateWithSwapChain(DriverType.Hardware, D3D11.DeviceCreationFlags.None, swapChainDesc,//GPU,none,description....
			out _d3DDevice, out _swapChain);//drivertype hard GPU good   soft Custom    refer CPU     warp CPU
            _d3DDeviceContext = _d3DDevice.ImmediateContext;
			using (D3D11.Texture2D backBuffer = _swapChain.GetBackBuffer<D3D11.Texture2D>(0))
            {
                _renderTargetView = new D3D11.RenderTargetView(_d3DDevice, backBuffer);
            }
			int col=0;
			RenderLoop.Run(rf,()=>{
			    //           	System.Threading.Thread.Sleep(5);
			               	col++;if(col>255){col=0;}
                           	_d3DDeviceContext.OutputMerger.SetRenderTargets(_renderTargetView);
                           	_d3DDeviceContext.ClearRenderTargetView(_renderTargetView, ColorToRaw4(Color.FromArgb(126,col,col)));
							
            				_swapChain.Present(1, PresentFlags.None);
			               });
		}
	}
}
