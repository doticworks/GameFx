﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2020/12/20
 * 时间: 16:02
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;

namespace doticworks.GameFx.DX.docs
{
	/// <summary>
	/// Description of iput.
	/// </summary>
	public class iput
	{
		public iput()
		{
			var dirInput = new SharpDX.DirectInput.DirectInput();
            var typeJoystick = SharpDX.DirectInput.DeviceType.Joystick;
            var allDevices = dirInput.GetDevices();
            bool isGetJoystick = false;
            foreach (var item in allDevices)
            {
                if (typeJoystick == item.Type)
                {
                    curJoystick = new SharpDX.DirectInput.Joystick(dirInput, item.InstanceGuid);
                    curJoystick.Acquire();
                    isGetJoystick = true;
                    Thread t1 = new Thread(joyListening);
                    t1.IsBackground = true;
                    t1.Start();
                }
            }
            if (!isGetJoystick)
            {
                MessageBox.Show("没有插入手柄");
            }
             if (SharpDX.DirectInput.DeviceType.Keyboard == item.Type)
                    {
                        var curKeyboard = new SharpDX.DirectInput.Keyboard(dirInput);
                        curKeyboard.Acquire();
                        var curKeyboardState = curKeyboard.GetCurrentState();
                        var curPressedKeys = curKeyboardState.PressedKeys;
                    }
		}
		 Device keyboard;
            keyboard = new Microsoft.DirectX.DirectInput.Device(SystemGuid.Keyboard);//实例化键盘对象 
            keyboard.SetCooperativeLeve(this,CooperativeLevelFlags.Background|CooperativeLevelFlags.NonExclusive); 
            keyboard.Acquire();//链接键盘设备 

            KeyboardState keys = keyboard.GetCurrentKeyboardState();  //获取键盘当前状态
            if (keys[Key.Escape])                        //如果按下ESC键
            { 
                DialogResult result=MessageBox.Show("是否退出程序？","提示",MessageBoxButtons.YesNo); 

         if (result == DialogResult.Yes) 
                { 
                    Application.Exit(); 
                }   
         
         
         
          Dim Devices = directInput.GetDevices(DeviceType.Keyboard, DeviceEnumerationFlags.AllDevices)
        For Each device In Devices
            If (device.Type = SharpDX.DirectInput.DeviceType.Keyboard) Then
                MyKeyboard = New SharpDX.DirectInput.Keyboard(directInput)
                MyKeyboard.Acquire()
            End If
        Next
	}
}
