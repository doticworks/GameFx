﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/20
 * 时间: 21:43
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Drawing;
namespace doticworks.GameFx.COMMON
{
	/// <summary>
	/// Description of Texture2Logic.
	/// </summary>
	public class Texture2Logic: Texture
	{
		public override Bitmap Paint(){
			return null;
		}
	}
}
