﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/11/20
 * 时间: 21:56
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;

namespace doticworks.GameFx.GAME
{
	/// <summary>
	/// Description of ShapePainter.
	/// </summary>
	public class ShapePainter
	{
		public ShapePainter()
		{
		}
	}
}
