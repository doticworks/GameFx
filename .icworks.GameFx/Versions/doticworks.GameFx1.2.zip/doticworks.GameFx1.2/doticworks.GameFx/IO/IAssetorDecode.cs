﻿/*
 * 由SharpDevelop创建。
 * 用户： DELL
 * 日期: 2020/12/10
 * 时间: 21:42
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;

namespace doticworks.GameFx.IO
{
	/// <summary>
	/// Description of IAssetorDecode.
	/// </summary>
	public interface IAssetorDecode
	{
		
	}
}
